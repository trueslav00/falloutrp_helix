LANGUAGE = {
    fonvHUD = "New Vegas HUD",
    optHudColor = "HUD Color"
}