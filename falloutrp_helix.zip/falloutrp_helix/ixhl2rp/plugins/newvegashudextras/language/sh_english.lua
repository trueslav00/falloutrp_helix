LANGUAGE = {
    fonvOxygenConfig = "New Vegas Oxygen Config",
    fonvWeaponConditionConfig = "New Vegas Weapon Condition Config",
    condition = "Condition",
    weaponBroke = "Внимание! %s сломан!"
}