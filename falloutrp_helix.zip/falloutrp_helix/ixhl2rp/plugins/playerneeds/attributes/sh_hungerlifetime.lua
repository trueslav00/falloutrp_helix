ATTRIBUTE.name = "Устойчивость к голоду"
ATTRIBUTE.description = "Lessens the need for food."
ATTRIBUTE.maxValue = 30