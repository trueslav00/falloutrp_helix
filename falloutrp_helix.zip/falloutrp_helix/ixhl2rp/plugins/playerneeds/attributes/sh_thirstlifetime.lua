ATTRIBUTE.name = "Устойчивость к жажде"
ATTRIBUTE.description = "Lessens the need for drink."
ATTRIBUTE.maxValue = 30