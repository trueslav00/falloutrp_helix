ITEM.name = "Приготовленные макароны с сыром"
ITEM.description = "Намного вкуснее мяса кротокрыса."
ITEM.model = "models/fnv/clutter/food/ramen01.mdl"
ITEM.category = "Food"
ITEM.price = 75
ITEM.restFood = 100
ITEM.sound = "player/footsteps/dirt1.wav"