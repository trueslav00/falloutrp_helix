ITEM.name = "Морковь"
ITEM.description = "Помойте, прежде чем есть."
ITEM.model = "models/fnv/clutter/food/carrot01.mdl"
ITEM.category = "Food"
ITEM.price = 8
ITEM.restFood = 5
ITEM.sound = "player/footsteps/dirt1.wav"