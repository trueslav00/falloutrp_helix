ITEM.name = "Бобовая бомба"
ITEM.description = "Довоенные консервированые бобы."
ITEM.model = "models/fnv/clutter/junk/porknbeans.mdl"
ITEM.category = "Food"
ITEM.price = 55
ITEM.restFood = 40
ITEM.sound = "player/footsteps/dirt1.wav"