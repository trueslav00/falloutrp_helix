ITEM.name = "Ланчбокс"
ITEM.description = "Ланчбокс с разной едой."
ITEM.model = "models/fnv/clutter/junk/nvlunchbox01.mdl"
ITEM.category = "Food"
ITEM.price = 150
ITEM.restFood = 100
ITEM.sound = "player/footsteps/dirt1.wav"