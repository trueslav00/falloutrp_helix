ITEM.name = "Макароны с сыром"
ITEM.description = "Можно есть и в сухом виде."
ITEM.model = "models/fnv/clutter/junk/blamcomacncheese.mdl"
ITEM.category = "Food"
ITEM.price = 15
ITEM.restFood = 20
ITEM.sound = "player/footsteps/dirt1.wav"