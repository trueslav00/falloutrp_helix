ITEM.name = "Яблоко"
ITEM.description = "Оно не с проста такое красное..."
ITEM.model = "models/fnv/clutter/food/apple02.mdl"
ITEM.category = "Food"
ITEM.price = 15
ITEM.restFood = 10
ITEM.sound = "player/footsteps/dirt1.wav"

ITEM.iconCam = {
	pos = Vector(509.25, 427.48, 311.06),
	ang = Angle(25.04, 220, 0),
	fov = 0.58
}
