ITEM.name = "Стейк"
ITEM.description = "На вкус как говядина."
ITEM.model = "models/fnv/clutter/food/steak01.mdl"
ITEM.category = "Food"
ITEM.price = 35
ITEM.restFood = 35
ITEM.sound = "player/footsteps/dirt1.wav"