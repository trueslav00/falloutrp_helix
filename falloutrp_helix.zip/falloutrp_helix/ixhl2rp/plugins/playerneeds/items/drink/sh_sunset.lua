ITEM.name = "Сансет Испарилла"
ITEM.description = "Вкусный напиток, известный в пустошах."
ITEM.model = "models/fnv/clutter/junk/ssbottle01.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 30
ITEM.sound = "eating_and_drinking/beerbottle.wav"