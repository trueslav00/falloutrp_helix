ITEM.name = "Пиво"
ITEM.description = "Самодельная брага, гордо носящая имя напитка покрепче."
ITEM.model = "models/fnv/clutter/food/beerbottle01.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 50
ITEM.sound = "eating_and_drinking/beerbottle.wav"
