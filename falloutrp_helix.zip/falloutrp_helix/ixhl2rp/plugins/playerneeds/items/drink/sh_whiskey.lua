ITEM.name = "Виски"
ITEM.description = "Заходит как-то раз ирландец в бар..."
ITEM.model = "models/fnv/clutter/liquorbottles/whiskeybottle01.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 30
ITEM.sound = "eating_and_drinking/beerbottle.wav"