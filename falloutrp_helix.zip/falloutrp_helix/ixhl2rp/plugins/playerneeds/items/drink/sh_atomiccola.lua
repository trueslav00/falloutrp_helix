ITEM.name = "Атомик-Кола"
ITEM.description = "Десять раз подумайте прежде чем пить это."
ITEM.model = "models/fnv/clutter/junk/nvatomiccocktail.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 30
ITEM.sound = "eating_and_drinking/beerbottle.wav"