ITEM.name = "Водка"
ITEM.description = "Между первой и второй..."
ITEM.model = "models/fnv/clutter/food/vodka01.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 30
ITEM.sound = "eating_and_drinking/beerbottle.wav"