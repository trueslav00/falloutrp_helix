ITEM.name = "Ядер-Кола"
ITEM.description = "От нее фонит радиацией..."
ITEM.model = "models/fnv/clutter/junk/nv/nvnukacolaquartz.mdl"
ITEM.category = "Drink"

ITEM.restThirst = 100
ITEM.sound = "eating_and_drinking/beerbottle.wav"