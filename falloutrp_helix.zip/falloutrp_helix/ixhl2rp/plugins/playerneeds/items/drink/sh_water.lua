ITEM.name = "Очищенная вода"
ITEM.description = "Обыкновенная чистая вода."
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl"
ITEM.category = "Drink"
ITEM.price = 25
ITEM.restThirst = 15
ITEM.sound = "eating_and_drinking/beerbottle.wav"