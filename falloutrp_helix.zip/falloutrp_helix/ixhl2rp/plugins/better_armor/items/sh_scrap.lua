ITEM.name = "Scrap Metal"
ITEM.model = Model("models/props_debris/metal_panelchunk02d.mdl")
ITEM.description = "Some shitty Metal."