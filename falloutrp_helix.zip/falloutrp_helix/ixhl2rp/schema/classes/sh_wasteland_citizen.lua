CLASS.name = "Обычный житель"
CLASS.faction = FACTION_WASTELANDS
CLASS.isDefault = true
CLASS_CITIZEN = CLASS.index