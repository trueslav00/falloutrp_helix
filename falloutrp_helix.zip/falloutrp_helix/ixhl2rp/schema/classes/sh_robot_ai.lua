CLASS.name = "Робот с ИИ"
CLASS.description = "Роботизированное существо с современным ИИ."
CLASS.isDefault = true
CLASS.faction = FACTION_ROBOTS
CLASS_CITIZEN = CLASS.index