CLASS.name = "Простой житель"
CLASS.faction = FACTION_VAULTS
CLASS.isDefault = true
CLASS_VCITIZEN = CLASS.index