ITEM.name = "Улучшенная гладкоствольная болтовка"
ITEM.description = "Теперь из нее можно стрелять... по жукам..."
ITEM.model = "models/illusion/fwp/w_pipeboltscoped.mdl"
ITEM.class = "aus_w_pipeboltscoped"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}