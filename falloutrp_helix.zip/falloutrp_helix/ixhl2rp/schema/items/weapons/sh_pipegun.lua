ITEM.name = "Гладкоствольная болтовка"
ITEM.description = "Каждый выстрел из нее может стать последним..."
ITEM.model = "models/illusion/fwp/w_pipebolt.mdl"
ITEM.class = "aus_w_pipebolt"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}