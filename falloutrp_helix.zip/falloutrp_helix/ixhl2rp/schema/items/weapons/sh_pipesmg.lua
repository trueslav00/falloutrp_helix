ITEM.name = "Гладкоствольная винтовка"
ITEM.description = "Полуавтоматическая винтовка с большим магазином."
ITEM.model = "models/illusion/fwp/w_pipeboltscoped.mdl"
ITEM.class = "aus_w_piperiflesemi"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}