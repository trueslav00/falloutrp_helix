ITEM.name = "Гладкоствольный револьвер"
ITEM.description = "Бам! Бам! Бам! Посмотрите на меня!"
ITEM.model = "models/illusion/fwp/w_piperevolver.mdl"
ITEM.class = "aus_w_piperevolver"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EOW}
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}