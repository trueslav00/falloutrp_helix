ITEM.name = "Армейский нож"
ITEM.description = "Обыкновенный армейский нож."
ITEM.model = "models/mosi/fallout4/props/weapons/melee/knife.mdl"
ITEM.class = "aus_m_knife_combatknife"
ITEM.weaponCategory = "melee"
ITEM.flag = "v"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(25.000, 220.000, 0.000),
	fov	= 3.780103254469,
	pos	= Vector(387.722321, 325.400116, 253.045181)
}
