ITEM.name = "Лазерный мушкет"
ITEM.description = "Самодельное лазерное оружие."
ITEM.model = "models/illusion/fwp/w_lasermusket.mdl"
ITEM.class = "aus_w_lasermusket"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 5
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}
