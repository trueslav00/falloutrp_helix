ITEM.name = "Кастет из когтей"
ITEM.description = "Оружие сильных воинов, что смогли одолеть когтя смерти и сделать из него... это."
ITEM.model = "models/mosi/fallout4/props/weapons/melee/deathclawgauntlet.mdl"
ITEM.class = "aus_m_fists_deathclawgauntlet"
ITEM.weaponCategory = "melee"
ITEM.flag = "v"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(25.000, 220.000, 0.000),
	fov	= 3.780103254469,
	pos	= Vector(387.722321, 325.400116, 253.045181)
}