ITEM.name = "Снайперская винтовка"
ITEM.description = "Мощная снайперская винтовка, способная одной пулей, прорешетить человека насквозь... А может даже и двух..."
ITEM.model = "models/weapons/hub/sniperrifle/sniperrifle.mdl"
ITEM.class = "aus_w_sniperrifle"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}