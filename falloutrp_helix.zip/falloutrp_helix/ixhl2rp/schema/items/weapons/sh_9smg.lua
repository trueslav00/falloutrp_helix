ITEM.name = ".9mm пистолет-пулемет"
ITEM.description = "Пробивная способность оставляет желать лучшего."
ITEM.model = "models/halokiller38/fallout/weapons/smgs/9mmsmg.mdl"
ITEM.class = "aus_w_9mmsmg"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 2
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}