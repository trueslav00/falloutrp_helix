ITEM.name = "Болтовка"
ITEM.description = "Старенькая ржавая болтовка."
ITEM.model = "models/illusion/fwp/w_varmintrifle.mdl"
ITEM.class = "aus_w_varmintrifle"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 5
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}
