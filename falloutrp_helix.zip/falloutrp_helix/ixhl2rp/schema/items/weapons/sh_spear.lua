ITEM.name = "Копье"
ITEM.description = "Древнейшее оружие созданное человеком, но актуальное и по сей день."
ITEM.model = "models/halokiller38/fallout/weapons/melee/spear.mdl"
ITEM.class = "aus_m_spear_poolcue"
ITEM.weaponCategory = "melee"
ITEM.flag = "v"
ITEM.width = 1
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(25.000, 220.000, 0.000),
	fov	= 3.780103254469,
	pos	= Vector(387.722321, 325.400116, 253.045181)
}