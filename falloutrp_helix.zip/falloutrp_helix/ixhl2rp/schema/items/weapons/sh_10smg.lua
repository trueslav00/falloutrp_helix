ITEM.name = ".10mm пистолет-пулемет"
ITEM.description = "Лучшее оружие из худшего."
ITEM.model = "models/halokiller38/fallout/weapons/smgs/10mmsmg.mdl"
ITEM.class = "aus_w_10mmsmg"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(25.000, 220.000, 0.000),
	fov	= 7.2253324508038,
	pos	= Vector(192.215500, 169.279007, 120.661133)
}