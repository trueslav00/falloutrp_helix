ITEM.name = "Дробовик караванщика"
ITEM.description = "Хорошо отпугивает радтараканов и криминальных личностей."
ITEM.model = "models/illusion/fwp/w_caravanshotgun.mdl"
ITEM.class = "aus_w_caravanshotgun"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}