ITEM.name = ".9mm пистолет"
ITEM.description = "Стандартный представитель гражданского довоенного вооружения."
ITEM.model = "models/halokiller38/fallout/weapons/pistols/9mmpistol.mdl"
ITEM.class = "aus_w_9mmpistol"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1

ITEM.iconCam = {
	pos = Vector(117.549286, 101.995529, 72.997093),
	ang = Angle(25.000, 220.000, 0.000),
	fov = 10.58
}