ITEM.name = ".44mm револьер"
ITEM.description = "Зовите меня мистер ковбой!"
ITEM.model = "models/halokiller38/fallout/weapons/pistols/44revolverunique.mdl"
ITEM.class = "aus_w_44magnum"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 5.412494001838,
	pos	= Vector(0, 200, 0)
}
