ITEM.name = ".10mm пистолет"
ITEM.description = "Старший брат 9-миллиметрового пистолета."
ITEM.model = "models/halokiller38/fallout/weapons/pistols/10mmpistol.mdl"
ITEM.class = "aus_w_10mmpistol"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-2.160, 359.379, 0.000),
	fov	= 10,
	pos	= Vector(-120, -0.520139, -5.542167)
}