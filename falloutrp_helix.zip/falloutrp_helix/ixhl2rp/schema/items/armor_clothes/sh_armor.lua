
ITEM.name = "Бронепластина"
ITEM.description = "Кустарная бронепластина изготовленная из разных материалов."
ITEM.category = "Clothing"
ITEM.model = "models/mosi/fallout4/props/junk/components/glass.mdl"
ITEM.flag = "v"
ITEM.maxArmor = 50