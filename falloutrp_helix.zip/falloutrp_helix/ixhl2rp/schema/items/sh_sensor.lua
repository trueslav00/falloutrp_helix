ITEM.name = "Сенсорный модуль"
ITEM.model = Model("models/mosi/fallout4/props/junk/sensormodule.mdl")
ITEM.description = "Странная пиликающая фиговина."
ITEM.price = 500