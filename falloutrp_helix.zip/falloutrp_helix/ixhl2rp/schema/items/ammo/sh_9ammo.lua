ITEM.name = ".9mm пистолетные патроны"
ITEM.model = "models/visualitygaming/fallout/ammo/9mm.mdl"
ITEM.ammo = "9mmRound" -- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "Небольшая коробочка с пулями для пистолета."
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.price = 20
ITEM.flag = "V"
