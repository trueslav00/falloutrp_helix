ITEM.name = "5.56mm винтовочные патроны"
ITEM.model = "models/mosi/fallout4/ammo/556.mdl"
ITEM.ammo = "GaussEnergy" -- type of the ammo
ITEM.ammoAmount = 60 -- amount of the ammo
ITEM.description = "Коробка с винтовочными патронами."
ITEM.classes = {CLASS_EOW}
ITEM.price = 60
ITEM.flag = "V"