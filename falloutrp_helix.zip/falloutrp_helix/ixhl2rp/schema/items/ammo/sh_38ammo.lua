ITEM.name = ".38 пули"
ITEM.model = "models/mosi/fallout4/ammo/38.mdl"
ITEM.ammo = "CombineCannon" -- type of the ammo
ITEM.ammoAmount = 18 -- amount of the ammo
ITEM.description = "Коробка с низкокалиберными револьверными патронами."
ITEM.classes = {CLASS_EOW}
ITEM.price = 20
ITEM.flag = "V"