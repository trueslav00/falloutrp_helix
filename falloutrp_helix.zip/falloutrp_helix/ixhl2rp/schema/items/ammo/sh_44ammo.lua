ITEM.name = ".44 пули"
ITEM.model = "models/mosi/fallout4/ammo/44.mdl"
ITEM.ammo = "357" -- type of the ammo
ITEM.ammoAmount = 12 -- amount of the ammo
ITEM.description = "Небольшая коробочка с револьверным пулями 44 калибра."
ITEM.classes = {CLASS_EOW}
ITEM.price = 35
ITEM.flag = "V"
