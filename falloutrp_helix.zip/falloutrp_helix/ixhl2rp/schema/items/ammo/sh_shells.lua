ITEM.name = "Гильзы для дробовика"
ITEM.model = "models/mosi/fallout4/ammo/38.mdl"
ITEM.ammo = "buckshot" -- type of the ammo
ITEM.ammoAmount = 18 -- amount of the ammo
ITEM.description = "Коробка с гильзами начиненными дробью."
ITEM.classes = {CLASS_EOW}
ITEM.price = 45
ITEM.flag = "V"