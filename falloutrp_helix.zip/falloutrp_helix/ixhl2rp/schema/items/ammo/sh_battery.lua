ITEM.name = "Микроядерная батарея"
ITEM.model = "models/mosi/fallout4/ammo/microfusioncell.mdl"
ITEM.ammo = "StriderMinigun" -- type of the ammo
ITEM.ammoAmount = 20 -- amount of the ammo
ITEM.description = "Используется для зарядки лазерного оружия и силовой брони."
ITEM.classes = {CLASS_EOW}
ITEM.price = 80
ITEM.flag = "V"