ITEM.name = ".10mm пистолетные патроны"
ITEM.model = "models/mosi/fallout4/ammo/10mm.mdl"
ITEM.ammo = "smg1" -- type of the ammo
ITEM.ammoAmount = 45 -- amount of the ammo
ITEM.description = "Коробка с крупнокалиберными пистолетными патронами."
ITEM.classes = {CLASS_EOW}
ITEM.price = 25
ITEM.flag = "V"