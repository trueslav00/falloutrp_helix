ITEM.name = "Шестеренки"
ITEM.model = Model("models/mosi/fallout4/props/junk/components/gears.mdl")
ITEM.description = "Коробочка с кучей шестеренок."
ITEM.price = 35