ITEM.name = "Зажигалка"
ITEM.model = Model("models/mosi/fallout4/props/junk/lighter.mdl")
ITEM.description = "Самое то для того чтобы разжечь костер... Или..."
ITEM.price = 35