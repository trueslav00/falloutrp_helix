ITEM.name = "Бандана"
ITEM.description = "Нацепив ее на лицо вы больше будете смахивать на головореза."
ITEM.outfitCategory = "Head"
ITEM.model = "models/tnb/items/facewrap.mdl"
ITEM.flag = "v"

ITEM.bodyGroups = {
    ["headgear"] = 1
}