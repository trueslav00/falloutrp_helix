ITEM.name = "Стальная броня"
ITEM.description = "Стильно, модно, опасно."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group005.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 2000

ITEM.replacements = {
	{"group004", "group011"}
}