ITEM.name = "Униформа солдат НКР"
ITEM.description = "Теперь вы больше похожи на грязного плутократа."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group055.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group055"}
}