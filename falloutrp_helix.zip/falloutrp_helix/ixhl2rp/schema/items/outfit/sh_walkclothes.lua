ITEM.name = "Прогулочная довоенная одежда"
ITEM.description = "Для особо богатых личностей."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group003.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group014"}
}