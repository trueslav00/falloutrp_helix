ITEM.name = "Одеяние странника"
ITEM.description = "Лучше чем ничего."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group060.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 500

ITEM.replacements = {
	{"group004", "group060"}
}