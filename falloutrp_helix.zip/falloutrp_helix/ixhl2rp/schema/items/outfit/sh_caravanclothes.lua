ITEM.name = "Одеяние караванщика"
ITEM.description = "Удобная и практичная одежда для тех, кто много носит с собой."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group002.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group013"}
}