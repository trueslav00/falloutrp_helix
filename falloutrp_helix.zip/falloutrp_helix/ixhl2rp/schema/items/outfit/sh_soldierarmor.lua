ITEM.name = "Военная экипировка"
ITEM.description = "Смотри не заразись духом патриотизма."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group012.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 2500

ITEM.replacements = {
	{"group004", "group012"}
}