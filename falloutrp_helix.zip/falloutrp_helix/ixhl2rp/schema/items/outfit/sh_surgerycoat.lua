ITEM.name = "Лабораторный халат"
ITEM.description = "Посмотрите кто у нас мистер всезнайка!"
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group007.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group007"}
}