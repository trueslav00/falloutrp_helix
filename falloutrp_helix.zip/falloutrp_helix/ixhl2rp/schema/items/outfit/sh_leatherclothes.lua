ITEM.name = "Кожаная жилетка"
ITEM.description = "Типичная одежда для байкера или просто чумового перца."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group061.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group061"}
}