ITEM.name = "Кожаная броня"
ITEM.description = "А вы точно не рейдер?"
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group052.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 750

ITEM.replacements = {
	{"group004", "group052"}
}