ITEM.name = "Шикарная одежда"
ITEM.description = "Теперь вы одеты как черт!"
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group001.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 120

ITEM.replacements = {
	{"group004", "group001"}
}