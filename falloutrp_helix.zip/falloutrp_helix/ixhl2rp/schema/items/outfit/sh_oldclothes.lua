ITEM.name = "Довоенная одежда"
ITEM.description = "Как же хорошо было раньше, когда не приходилось убивать людей ради еды."
ITEM.category = "Clothing"
ITEM.model = "models/thespireroleplay/items/clothes/group059.mdl"
ITEM.flag = "v"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 750

ITEM.replacements = {
	{"group004", "group059"}
}