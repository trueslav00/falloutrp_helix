ITEM.name = "Бейсбольный мяч"
ITEM.model = Model("models/props_wasteland/prison_toiletchunk01f.mdl")
ITEM.description = "Бита в комплект не входит."
ITEM.price = 35