ITEM.name = "Гантеля"
ITEM.model = Model("models/props_wasteland/prison_toiletchunk01f.mdl")
ITEM.description = "Гантеля на 2.5 килограмма."
ITEM.price = 20