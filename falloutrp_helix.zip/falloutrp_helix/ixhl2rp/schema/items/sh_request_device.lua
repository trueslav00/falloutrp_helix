
ITEM.name = "Радиопередатчик"
ITEM.model = Model("models/gibs/shield_scanner_gib1.mdl")
ITEM.description = "Небольшое устройство с функцией радиопередачи на одной волне."
ITEM.price = 220
