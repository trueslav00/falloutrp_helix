ITEM.name = "Тостер"
ITEM.model = Model("models/mosi/fallout4/props/junk/toaster.mdl")
ITEM.description = "Обычный ржавый тостер, ничего примечательного."
ITEM.price = 35