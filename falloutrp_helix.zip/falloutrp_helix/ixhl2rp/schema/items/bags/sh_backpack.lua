ITEM.name = "Рюкзак"
ITEM.description = "Небольшой рюкзак."
ITEM.model = Model("models/vex/seventysix/backpacks/backpack_01.mdl")