ITEM.name = "Чемодан"
ITEM.description = "Небольшой чемодан."
ITEM.model = Model("models/weapons/w_suitcase_passenger.mdl")