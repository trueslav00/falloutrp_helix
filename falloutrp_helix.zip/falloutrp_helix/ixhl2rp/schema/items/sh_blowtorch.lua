ITEM.name = "Паяльная лампа"
ITEM.model = Model("models/mosi/fallout4/props/junk/blowtorch.mdl")
ITEM.description = "Не направляйте в сторону лица!"
ITEM.price = 20