ITEM.name = "Плюшевый мишка"
ITEM.model = Model("models/mosi/fallout4/props/junk/teddybear01.mdl")
ITEM.description = "Милая вещичка, напоминающая о довоенном времени."
ITEM.price = 100