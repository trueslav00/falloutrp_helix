ITEM.name = "Кусок стали"
ITEM.model = Model("models/mosi/fallout4/props/junk/components/steel.mdl")
ITEM.description = "Тяжелый..."
ITEM.price = 70