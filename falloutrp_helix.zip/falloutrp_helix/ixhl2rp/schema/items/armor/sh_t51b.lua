ITEM.name = "Силовая броня Т-51Б"
ITEM.description = "Выглядит значительно более крепкой, чем другие виды брони. Цельные титановые и композитные пластины закрывают все части тела бойца, а аккумулятор, заправленный ядерным топливом, способен работать до 100 лет."
ITEM.category = "armor"
ITEM.model = "models/thespireroleplay/items/powerarmor_go.mdl"
ITEM.flag = "v"
ITEM.width = 4
ITEM.height = 4
ITEM.price = 10000
ITEM.resistance = true -- This will activate the protection bellow
ITEM.damage = { -- It is scaled; so 100 damage * 0.8 will makes the damage be 80.
			0.4, -- Bullets
			0.65, -- Slash
			0.95, -- Shock
			0.6, -- Burn
			0.3, -- Radiation
			0.9, -- Acid
			0.5, -- Explosion
}
ITEM.replacements = {
	{"group004", "group056"}
}