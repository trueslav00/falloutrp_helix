ITEM.name = "Улучшенная Силовая Броня"
ITEM.description = "Вы ощущаете как в ваших руках находится одна из самых технологичных и могущественных вещей во всей Пустоши. Улучшенная Силовая Броня первой модели использует легкие сплавы металлов как основные плиты, а точки их соединения усилены керамикой, а питается от собственного термоядерного реактора, заправленного топливом на сотни лет."
ITEM.category = "armor"
ITEM.model = "models/thespireroleplay/items/powerarmor_go.mdl"
ITEM.flag = "v"
ITEM.width = 4
ITEM.height = 4
ITEM.price = 20000
ITEM.resistance = true -- This will activate the protection bellow
ITEM.damage = { -- It is scaled; so 100 damage * 0.8 will makes the damage be 80.
			0.45, -- Bullets
			0.7, -- Slash
			0.95, -- Shock
			0.65, -- Burn
			0.35, -- Radiation
			0.95, -- Acid
			0.55, -- Explosion
}
ITEM.replacements = "models/nikout/advancedpowerarmor.mdl"