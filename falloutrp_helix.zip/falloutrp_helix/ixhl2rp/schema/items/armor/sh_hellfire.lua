ITEM.name = "Силовая Броня Геенна"
ITEM.description = "Секретный прототип Анклава, созданный для самых элитных десантников на Восточном побережье СЩА. Как он попал сюда - непонятно. Но понятно то, что эта броня является наилучшей благодаря своей защите от огня и утолщенным керамическим пластинам."
ITEM.category = "armor"
ITEM.model = "models/thespireroleplay/items/powerarmor_go.mdl"
ITEM.flag = "v"
ITEM.width = 4
ITEM.height = 4
ITEM.price = 50000
ITEM.resistance = true -- This will activate the protection bellow
ITEM.damage = { -- It is scaled; so 100 damage * 0.8 will makes the damage be 80.
			0.55, -- Bullets
			0.75, -- Slash
			0.95, -- Shock
			0.85, -- Burn
			0.4, -- Radiation
			0.95, -- Acid
			0.65, -- Explosion
}
ITEM.replacements = "models/f3v/hellfire.mdl"