ITEM.name = "Улучшенная Силовая Броня Второй Модели"
ITEM.description = "Стандартная силовая броня Анклава, являющаяся лучшим методом защиты на пустоши. Улучшенная Силовая Броня второй модели полностью использует сплавы из керамики и металла, а питается от собственного термоядерного реактора, заправленного топливом на сотни лет."
ITEM.category = "armor"
ITEM.model = "models/thespireroleplay/items/powerarmor_go.mdl"
ITEM.flag = "v"
ITEM.width = 4
ITEM.height = 4
ITEM.price = 25000
ITEM.resistance = true -- This will activate the protection bellow
ITEM.damage = { -- It is scaled; so 100 damage * 0.8 will makes the damage be 80.
			0.5, -- Bullets
			0.75, -- Slash
			0.95, -- Shock
			0.7, -- Burn
			0.4, -- Radiation
			0.95, -- Acid
			0.6, -- Explosion
}
ITEM.replacements = "models/fallout_3/enclave_power_armor.mdl"