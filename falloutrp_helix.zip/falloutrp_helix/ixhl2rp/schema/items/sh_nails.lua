ITEM.name = "Гвозди"
ITEM.model = Model("models/mosi/fallout4/ammo/railwayspikes.mdl")
ITEM.description = "Несколько гвоздиков."
ITEM.price = 35