ITEM.name = "Канистра"
ITEM.model = Model("models/mosi/fallout4/props/junk/aluminumcannister.mdl")
ITEM.description = "Алюминиевая канистра для бензина."
ITEM.price = 50