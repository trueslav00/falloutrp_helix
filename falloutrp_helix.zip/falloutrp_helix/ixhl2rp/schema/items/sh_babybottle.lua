ITEM.name = "Бутылка с соской"
ITEM.model = Model("models/mosi/fallout4/props/junk/babybottle01.mdl")
ITEM.description = "Она явно использовалась не по назначению..."
ITEM.price = 20